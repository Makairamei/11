
import express from "express";
import cors from "cors";
import fs from "fs";
import { v4 as uuidv4 } from "uuid";

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

const dbPath = "./db.json";
const readDB = () => JSON.parse(fs.readFileSync(dbPath, "utf-8"));
const writeDB = (data) => fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));

if (!fs.existsSync(dbPath)) writeDB({});

app.get("/", (req, res) => res.send("Multi-Login Backend is running"));

app.get("/generate-token", (req, res) => {
  const token = uuidv4();
  const db = readDB();
  db[token] = {};
  writeDB(db);
  res.json({ token });
});

app.post("/upload-cookies", (req, res) => {
  const { token, domain, cookies } = req.body;
  if (!token || !domain || !cookies) return res.status(400).json({ error: "Missing fields" });
  const db = readDB();
  if (!db[token]) db[token] = {};
  db[token][domain] = cookies;
  writeDB(db);
  res.json({ success: true });
});

app.get("/cookies/:token", (req, res) => {
  const { token } = req.params;
  const db = readDB();
  res.json(db[token] || {});
});

app.listen(PORT, "0.0.0.0", () => console.log(`Backend running at http://0.0.0.0:${PORT}`));
