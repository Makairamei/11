
document.addEventListener("DOMContentLoaded", () => {
  const tokenInput = document.getElementById("token");
  const msg = document.getElementById("msg");

  chrome.storage.local.get("token", (data) => {
    if (data.token) tokenInput.value = data.token;
  });

  document.getElementById("generate").onclick = async () => {
    const res = await fetch("http://172.83.14.144:3000/generate-token");
    const data = await res.json();
    chrome.storage.local.set({ token: data.token });
    tokenInput.value = data.token;
    msg.textContent = "Token generated & saved!";
  };

  document.getElementById("upload").onclick = () => {
    const token = tokenInput.value.trim();
    if (!token) return (msg.textContent = "Token kosong!");
    chrome.storage.local.set({ token });
    chrome.cookies.getAll({ domain: "bilibili.tv" }, async (cookies) => {
      const payload = {
        token,
        domain: "bilibili.tv",
        cookies,
      };
      await fetch("http://172.83.14.144:3000/upload-cookies", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      msg.textContent = "Cookies uploaded!";
    });
  };
});
