
chrome.runtime.onInstalled.addListener(() => {
  console.log("Extension installed.");
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url.includes("bilibili.tv")) {
    chrome.storage.local.get("token", async (data) => {
      if (!data.token) return;
      const res = await fetch("http://172.83.14.144:3000/cookies/" + data.token);
      const cookies = await res.json();
      const siteCookies = cookies["bilibili.tv"] || [];
      siteCookies.forEach((ck) => {
        chrome.cookies.set({
          url: "https://www.bilibili.tv",
          name: ck.name,
          value: ck.value,
          domain: ".bilibili.tv",
          path: ck.path,
        });
      });
    });
  }
});
